interface ElementoVenta {
    double calcularPrecio();
}
